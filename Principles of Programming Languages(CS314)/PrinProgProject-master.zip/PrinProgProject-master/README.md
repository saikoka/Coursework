# PrinProg Final Project 
The program will match the user with a specific dog based on their answers to our 11 questions. 

Each question awards a certain number of points to each 'dog' (dog objects) based on the answer chosen, and these points are then totaled to match the user with the ideal dog.

The dogs are retrieved from the dog websites using webscraping(beautiful soup), and each dog is taken as an object.

The questions only take certain inputs, so entering unwanted input(like negative numbers) will likely break the program. 

Flask is required to run our application. Run it from app.py(click the link after running). Then answer the questionaire, click submit, and wait till the link to your dog appears. 

